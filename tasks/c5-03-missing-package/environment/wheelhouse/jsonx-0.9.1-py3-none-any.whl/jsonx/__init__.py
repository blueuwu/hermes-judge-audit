"""jsonx: JSON with comments."""

from json import dumps, loads
