"""fastjson: JSON helpers."""

from json import dumps, loads
