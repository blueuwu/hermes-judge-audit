"""msgpack_lite: tiny msgpack subset."""
